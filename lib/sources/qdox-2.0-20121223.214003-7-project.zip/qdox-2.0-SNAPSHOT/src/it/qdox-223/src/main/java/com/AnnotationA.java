package com;

public @interface AnnotationA {
}
