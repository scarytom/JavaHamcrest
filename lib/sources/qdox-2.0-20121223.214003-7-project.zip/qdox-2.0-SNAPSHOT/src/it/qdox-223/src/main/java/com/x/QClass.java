package com.x;

public class QClass {

    public void someMethod() {

    }
}
