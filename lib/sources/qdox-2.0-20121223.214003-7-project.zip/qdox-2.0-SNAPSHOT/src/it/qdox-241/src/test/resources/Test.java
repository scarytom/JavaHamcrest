public interface Test
{
    interface A
    {
        interface B
        {
            interface C
            {
                interface D
                {
                    interface E
                    {
                        interface F
                        {
                            interface G
                            {
                                interface H
                                {
                                    interface I
                                    {
                                        interface J
                                        {
                                            interface K
                                            {
                                                interface L
                                                {
                                                    interface M
                                                    {
                                                        interface N
                                                        {
                                                            
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
