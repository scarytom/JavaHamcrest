/**
 * Provides classes to visit all files within a directory matching a certain filter 
 */
package com.thoughtworks.qdox.directorywalker;