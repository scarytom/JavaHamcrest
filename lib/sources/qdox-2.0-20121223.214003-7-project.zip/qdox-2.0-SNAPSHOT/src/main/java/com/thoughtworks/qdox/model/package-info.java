/**
 * Provides classes reflecting the Java model elements.
 * These classes are often richer then their <code>java.reflect</code> equivalent. 
 */
package com.thoughtworks.qdox.model;