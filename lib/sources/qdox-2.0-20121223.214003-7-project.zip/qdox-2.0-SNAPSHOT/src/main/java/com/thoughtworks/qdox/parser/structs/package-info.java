/**
 * Provides simple models to be constructed by the parser.
 * With these objects the ModeLbuilder constructs a complete Java Model
 */
package com.thoughtworks.qdox.parser.structs;